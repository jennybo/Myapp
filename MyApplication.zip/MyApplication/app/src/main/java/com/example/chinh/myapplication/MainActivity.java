package com.example.chinh.myapplication;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<String> list;
    private ListView lv;
    private DBManager dbManager;
    private EditText textView;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.button);
        textView = (EditText) findViewById(R.id.editText);
        lv = (ListView) findViewById(R.id.lv);
        list = new ArrayList<String>();
        dbManager = new DBManager(this, "CongViec.sqlite", null, 1);
        dbManager.QueryData("CREATE TABLE IF NOT EXISTS CongViec(Id INTEGER PRIMARY KEY AUTOINCREMENT,TenCV VARCHAR(200))");
//        dbManager.QueryData("INSERT INTO CongViec VALUES(null,'anh yeu em.')");
//        dbManager.QueryData("INSERT INTO CongViec VALUES(null,'vi ke ngu ngo.')");
//        dbManager.QueryData("INSERT INTO CongViec VALUES(null,'nen anh moi noi.')");
//        dbManager.QueryData("INSERT INTO CongViec VALUES(null,'anh yeu em.')");
        Cursor cursor = dbManager.GetData("SELECT * FROM CongViec");
        if (cursor != null && cursor.moveToFirst())
            do {
                list.add(cursor.getString(1));
            } while (cursor.moveToNext());
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        lv.setAdapter(adapter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!textView.getText().toString().equals("")) {
                    list.add(textView.getText().toString());
                    adapter.notifyDataSetChanged();
                    lv.setAdapter(adapter);
                    dbManager.QueryData("INSERT INTO CongViec VALUES(null,'" + textView.getText().toString() + "')");
                    textView.setText("");
                }
            }
        });
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String dd = list.get(position);
                dbManager.QueryData("DELETE FROM CongViec WHERE TenCV = '" + dd + "'");
                list.remove(position);
                adapter.notifyDataSetChanged();
            }
        });
        textView.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    switch (keyCode)
                    {
                        case KeyEvent.KEYCODE_ENTER:
                            if (!textView.getText().toString().equals("")) {
                                list.add(textView.getText().toString());
                                adapter.notifyDataSetChanged();
                                lv.setAdapter(adapter);
                                dbManager.QueryData("INSERT INTO CongViec VALUES(null,'" + textView.getText().toString() + "')");
                                textView.setText("");
                            }
                            return true;
                            default:
                                break;
                    }
                }
                return false;
            }
        });
    }
}